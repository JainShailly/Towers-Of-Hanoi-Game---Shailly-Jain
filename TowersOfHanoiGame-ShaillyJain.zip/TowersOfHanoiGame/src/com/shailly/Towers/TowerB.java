package com.shailly.Towers;

import javafx.scene.shape.Rectangle;

import java.util.Stack;

public class TowerB {

    private int columnIndex;
    private Stack<Rectangle> stackB;
    private double sizeOfTopRectangle;

    public TowerB(int columnIndex) {
        this.columnIndex = columnIndex;
        stackB = new Stack<>(); // initialize the stack
        sizeOfTopRectangle = 220.0 ; // no rectangle placed on TowerC yet
    }

    public Rectangle getRectangle(){
        if(stackB.empty()){
            return null;
        }else{
            Rectangle rectangle = stackB.pop();
            this.sizeOfTopRectangle = stackB.empty() ? 220.0 : stackB.lastElement().getWidth()/20;
            return rectangle;
        }
    }

    public void addRectangle(Rectangle rectangle){
        if(rectangle != null){
            stackB.push(rectangle);
            this.sizeOfTopRectangle = rectangle.getWidth()/20;
        }
    }

    public double getSizeOfTopRectangle(){
        return this.sizeOfTopRectangle;
    }

    public int getColumnIndex() {
        return columnIndex;
    }
    public int getSize(){
        return this.stackB.size();
    }

}
