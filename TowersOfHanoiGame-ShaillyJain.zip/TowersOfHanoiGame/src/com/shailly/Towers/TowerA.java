package com.shailly.Towers;

import javafx.scene.shape.Rectangle;

import java.util.Stack;

public class TowerA {
    private int columnIndex;
    private Stack<Rectangle> stackA;
    private double sizeOfTopRectangle;

    public TowerA(int columnIndex) {
        this.columnIndex = columnIndex;
        stackA = new Stack<>(); // initialize the stack
        sizeOfTopRectangle = 220.0 ; // no rectangle placed on TowerC yet
    }

    public Rectangle getRectangle(){
        if(stackA.empty()){
            return null;
        }else{
            Rectangle rectangle = stackA.pop();
            this.sizeOfTopRectangle = stackA.empty() ? 220.0 : stackA.lastElement().getWidth()/20;
            return rectangle;
        }
    }

    public void addRectangle(Rectangle rectangle){
        if(rectangle != null){
            stackA.push(rectangle);
            this.sizeOfTopRectangle = rectangle.getWidth()/20;
        }
    }

    public double getSizeOfTopRectangle(){
        return this.sizeOfTopRectangle;
    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public int getSize(){
        return this.stackA.size();
    }
}
