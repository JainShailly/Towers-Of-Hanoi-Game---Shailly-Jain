package com.shailly;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;


public class Instructions {

    @FXML
    public TextArea textArea;

    @FXML
    public void initialize(){
        String text = "Each level of \"Towers of Hanoi Game\" gives you three towers namely TowerA, TowerB and TowerC. " +
                "TowerA contains a certain number of plates in some order of size. Your task is to move all these plates from TowerA to TowerB" +
                ", using TowerC following these Rules:\n" +
                "Rule1: You can move only one plate at a time.\n" +
                "Rule2: A plate of large size cannot be placed over a plate of smaller size.\n" +
                "Rule3: No Time Limit";
        textArea.setText(text);
        textArea.setEditable(false);
    }
}
