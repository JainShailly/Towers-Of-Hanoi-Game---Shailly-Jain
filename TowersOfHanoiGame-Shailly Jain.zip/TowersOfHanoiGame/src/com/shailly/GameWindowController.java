package com.shailly;

import com.shailly.Towers.TowerA;
import com.shailly.Towers.TowerB;
import com.shailly.Towers.TowerC;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Rectangle;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class GameWindowController {

    @FXML
    public GridPane gridPane;
    @FXML
    public Rectangle first, second, third, fourth, fifth, sixth, seventh, eighth, ninth, tenth;
    @FXML
    public ChoiceBox<String> source, destination;
    @FXML
    public Button move;

    private TowerA towerA;
    private TowerB towerB;
    private TowerC towerC;
    private int numberOfDisks;

    @FXML
    public  Rectangle[] rectangles;

    @FXML
    public void initialize(){


        // initializes the towers
        towerA = new TowerA(1);
        towerB = new TowerB(4);
        towerC = new TowerC(7);

        //initialize the source and destination lists
        source.getItems().addAll("TowerA","TowerB","TowerC");
        destination.getItems().addAll("TowerA","TowerB","TowerC");
        source.getSelectionModel().selectFirst();
        destination.getSelectionModel().selectFirst();

        // initialize the rectangles list
        rectangles = new Rectangle[10];
        rectangles[0] = first;
        rectangles[1] = second;
        rectangles[2] = third;
        rectangles[3] = fourth;
        rectangles[4] = fifth;
        rectangles[5] = sixth;
        rectangles[6] = seventh;
        rectangles[7] = eighth;
        rectangles[8] = ninth;
        rectangles[9] = tenth;

        // set the visibility of each rectangle to be false
        for(int i = 0 ; i <10; ++i){
            rectangles[i].setVisible(false);
        }
    }

    public void setTowerAContent(int level){
        numberOfDisks = level; // set the number of disks
        for(int i = 9 ; i >9 - level ; --i){
            towerA.addRectangle(rectangles[i]);
            rectangles[i].setVisible(true);
        }
    }

    @FXML
    public void handleMoveButton(){
        String sourceTower = source.getValue();
        String destinationTower = destination.getValue();


        if(sourceTower.equals(destinationTower)){
            showAlert("Source and Destination Towers cannot be the same.");
        }else if(sourceTower.equals("TowerA") && destinationTower.equals("TowerB")){
            if(towerB.getSizeOfTopRectangle() > towerA.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerA.getRectangle();
                if(rectangle != null){
                    towerB.addRectangle(rectangle);
                    int columnIndex = towerB.getColumnIndex();
                    int rowIndex = 19 - towerB.getSize() + 1;
                    int incomingRow = 19 - towerA.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }
                }
            }else{
                if(towerA.getSize() == 0){
                    showAlert("TowerA do not contain any disks.");
                }else{
                    showAlert("Disk from TowerA cannot be moved to disk on TowerB because of size constraints.");
                }
            }
        }else if(sourceTower.equals("TowerA") && destinationTower.equals("TowerC")){
            if(towerC.getSizeOfTopRectangle() > towerA.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerA.getRectangle();
                if(rectangle != null){
                    towerC.addRectangle(rectangle);
                    int columnIndex = towerC.getColumnIndex();
                    int rowIndex = 19 - towerC.getSize() + 1;
                    int incomingRow = 19 - towerA.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }

                }
            }else{
                if(towerA.getSize() == 0){
                    showAlert("TowerA do not contain any disks.");
                }else{
                    showAlert("Disk from TowerA cannot be moved to disk on TowerC because of size constraints.");
                }
            }
        }else if(sourceTower.equals("TowerB") && destinationTower.equals("TowerA")){
            if(towerA.getSizeOfTopRectangle() > towerB.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerB.getRectangle();
                if(rectangle != null){
                    towerA.addRectangle(rectangle);
                    int columnIndex = towerA.getColumnIndex();
                    int rowIndex = 19 - towerA.getSize() + 1;
                    int incomingRow = 19 - towerB.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }

                }
            }else{
                if(towerB.getSize() == 0){
                    showAlert("TowerB do not contain any disks.");
                }else{
                    showAlert("Disk from TowerB cannot be moved to disk on TowerA because of size constraints.");
                }
            }
        }else if(sourceTower.equals("TowerB") && destinationTower.equals("TowerC")){
            if(towerC.getSizeOfTopRectangle() > towerB.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerB.getRectangle();
                if(rectangle != null){
                    towerC.addRectangle(rectangle);
                    int columnIndex = towerC.getColumnIndex();
                    int rowIndex = 19 - towerC.getSize() + 1;
                    int incomingRow = 19 - towerB.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }

                }
            }else{
                if(towerB.getSize() == 0){
                    showAlert("TowerB do not contain any disks.");
                }else{
                    showAlert("Disk from TowerB cannot be moved to disk on TowerC because of size constraints.");
                }
            }
        }else if(sourceTower.equals("TowerC") && destinationTower.equals("TowerA")){
            if(towerA.getSizeOfTopRectangle() > towerC.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerC.getRectangle();
                if(rectangle != null){
                    towerA.addRectangle(rectangle);
                    int columnIndex = towerA.getColumnIndex();
                    int rowIndex = 19 - towerA.getSize() + 1;
                    int incomingRow = 19 - towerC.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }

                }
            }else{
                if(towerC.getSize() == 0){
                    showAlert("TowerC do not contain any disks.");
                }else{
                    showAlert("Disk from TowerC cannot be moved to disk on TowerA because of size constraints.");
                }
            }
        }else if(sourceTower.equals("TowerC") && destinationTower.equals("TowerB")){
            if(towerB.getSizeOfTopRectangle() > towerC.getSizeOfTopRectangle()){
                // we can shift the disk
                Rectangle rectangle = towerC.getRectangle();
                if(rectangle != null){
                    towerB.addRectangle(rectangle);
                    int columnIndex = towerB.getColumnIndex();
                    int rowIndex = 19 - towerB.getSize() + 1;
                    int incomingRow = 19 - towerC.getSize() ;
                    try{

                        gridPane.add(rectangle,columnIndex,rowIndex);
                        // since duplicate element is added to the grid pane, so definitely there will be
                        // an IllegalArgumentException
                    }catch(IllegalArgumentException e){
                        // we don't care for this exception
                    }

                }
            }else{
                if(towerC.getSize() == 0){
                    showAlert("TowerC do not contain any disks.");
                }else{
                    showAlert("Disk from TowerC cannot be moved to disk on TowerB because of size constraints.");
                }
            }
        }

        if(towerA.getSize() == 0 && towerB.getSize() == numberOfDisks){
            if(numberOfDisks != 10){
                String text = "Congratulations!! \nYou have cleared the \"Level" + numberOfDisks+ " of " + "\"Towers Of Hanoi\".";
                showAppreciation(text);
                text = "Please close the window and move on to the next level of \"Towers Of Hanoi\".";
                showAppreciation(text);
            }else{
                String text = "Hurrah!! \nYou have cracked the game of \"Towers Of Hanoi\"" +
                        "\nYou are a Genius-\"Computer Scientist\"";
                showAppreciation(text);

                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Towers Of Hanoi- Champion");
                dialog.getDialogPane().setHeaderText(null);
                dialog.getDialogPane().setContentText("Dear Champion, Please provide us your name.");
                Optional<String> result = dialog.showAndWait();
                if(result.isPresent()){
                   String name = result.get(); // get the name typed by the winner
                   if(!name.trim().isEmpty()){
                       // a valid name
                       try{
                           FileWriter writer = new FileWriter("Champions.txt");
                           BufferedWriter bw = new BufferedWriter(writer);
                           bw.append(name);
                           bw.append("\t");
                           bw.append("" + LocalDate.now().format(DateTimeFormatter.ofPattern(
                                   "E, d MMM YYYY")));
                           bw.newLine();
                           bw.close();
                           writer.close();
                       }catch(IOException e){
                           System.out.println("Could not open the file Champions.txt");
                       }
                   }
                }
            }
        }
    }

    private void showAppreciation(String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Towers Of Hanoi- You Won");
        alert.setContentText(msg);
        alert.showAndWait();
    }


    private void showAlert(String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Towers of Hanoi Game- Invalid Move");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
