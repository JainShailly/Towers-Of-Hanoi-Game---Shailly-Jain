package com.shailly;


import javafx.application.Platform;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Optional;

public class Controller {

    private int gameLevel;

    @FXML
    public Button playButton,instructionsButton, leadersButton,quitButton,levelButton;

    @FXML
    public void initialize(){
        try{
            playButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("playIcon.png"))));
        }catch(Exception e){
            System.out.println("Could not find the icon playIcon.png");
        }
        try{
            instructionsButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("instructionsIcon.gif"))));
        }catch(Exception e){
            System.out.println("Could not find the icon instructionsIcon.gif");
        }
        try{
            leadersButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("leadersIcon.gif"))));
        }catch(Exception e){
            System.out.println("Could not find the icon leadersIcon.gif");
        }
        try{
            levelButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("levelIcon.gif"))));
        }catch(Exception e){
            System.out.println("Could not find the icon levelIcon.gif");
        }
        try{
            quitButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("quitIcon.gif"))));
        }catch(Exception e){
            System.out.println("Could not find the icon quitIcon.gif");
        }

        this.gameLevel = 1; // start from level1 by default
    }

    @FXML
    public void handlePlayGameButton(){
        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader =  new FXMLLoader();
        loader.setLocation(getClass().getResource("gameWindow.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file gameWindow.fxml");
            return;
        }
        // file loaded successfully
        dialog.setTitle("Towers Of Hanoi Game");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CLOSE);
        GameWindowController controller = loader.getController();
        controller.setTowerAContent(this.gameLevel);
        dialog.showAndWait();
    }

    @FXML
    public void handleMouseEnterForButton(Event e){
        Button button = (Button)e.getSource();
        button.setTextFill(Paint.valueOf("crimson"));
        button.setScaleX(1.2);
        button.setScaleY(1.2);
    }

    @FXML
    public void handleMouseExitForButton(Event e){
        Button button = (Button)e.getSource();
        button.setTextFill(Paint.valueOf("blue"));
        button.setScaleX(1.0);
        button.setScaleY(1.0);
    }

    @FXML
    public void handleInstructionButton(){
        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(this.getClass().getResource("instructionsPage.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file instructions.fxml");
            return;
        }
        // file loaded successfully
        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.setTitle("Towers Of Hanoi Game- Instructions");
        dialog.showAndWait();
    }


    @FXML
    public void handleLeadersButton(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Towers Of Hanoi- Leader's List");
        alert.setHeaderText(null);
        String text = "Leader's List\n";

        try{
            FileReader reader = new FileReader("Champions.txt");
            BufferedReader br = new BufferedReader(reader);
            String line ;
            while( (line = br.readLine())!=null ){
                String[] parts = line.split("\t");
                text += "Champion's Name: " + parts[0] + "\n";
                text += "Game Cracking Date: " + parts[1] + "\n";
            }
            br.close();
            reader.close();
        }catch(IOException e){
            // could not load the file champions.txt
            text = "No one cracked the game \"Towers Of Hanoi\" yet.\n" +
                    "You might be the first one. Good luck :)";
            alert.setContentText(text);
            alert.showAndWait();
            return;
        }
        alert.setContentText(text);
        alert.showAndWait();
    }

    @FXML
    public void handleSelectLevelButton(){
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Towers Of Hanoi-Select Level");
        dialog.getDialogPane().setHeaderText(null);
        dialog.getDialogPane().setContentText("Please enter the level(1-10)");
        Optional<String> result = dialog.showAndWait();
        boolean isValid = false;
        if(result.isPresent()){
            try{
                int level = Integer.parseInt(result.get());
                if(level >= 1 && level <= 10){
                    // valid level
                    this.gameLevel = level;
                    isValid = true;
                }else{
                    // not a valid level
                }
            }catch(NumberFormatException e){
                // not a valid level
            }
        }
        String text = isValid ? ("You selected the Level" + gameLevel + "\n" +
                "Enjoy your game. We wish you \"All the Best\"") : ("Oops, the level you provided does not seems to be valid :(");
        Alert.AlertType type = isValid ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR;
        Alert alert = new Alert(type);
        alert.setTitle("Towers Of Hanoi- Select Level");
        alert.setHeaderText(null);
        alert.setContentText(text);
        alert.showAndWait();

    }

    @FXML
    public void handleQuitButton(){
        Platform.exit();
    }
}
